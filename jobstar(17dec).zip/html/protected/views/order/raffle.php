<section class="banner">
<img src="image/slide4.jpg" alt="Banner">
</section>
<div id="maincontainer">
  <section id="gopremium">
    <div class="container">
     <h1 class="heading1"><span class="maintext">Raffles</span></h1>
<div class="row">
<div class="span8">
	<div class="daysuntil">
    	<h4>Days Until Next Raffle</h4>
        <p class="value">000</p>
        <p class="days">Day(s)</p>
    </div>
</div>
<div class="span4 nextprize"><img src="image/next-prize-img.jpg" alt="Next Prize"></div>

</div>

 <h1 class="heading1"><span class="maintext">Hall Of Fame – Previous Winners</span></h1>
 <div class="row winnersrow">
 <div class="span3 winnerimg"><img src="image/raffle-img1.png"  alt="Raffle winners"></div>
 <div class="span9 winnerinfo">
 
 <h4>Sir Betty</h4>
					<p class="member_position">Winner 12/04/2015</p>
					
<p>Sir Betty&nbsp;was our winner for the Duel Lego Box on the 21st December 2014. Then we fill in loads more text about a farm Animal with a machine Gun that shoots out potatoes.And the we go ahead and enter loads of more text because it looks much better to have a certain amount of text rather than a empty pocket</p>

					<ul class="social_links unstyled"><li><a class="facebook_icon" href="http://BarrackObamawasourwinnerfortheDuelLegoBoxonthe21stDecember2014"><i class="fa fa-facebook"></i></a></li>
                    <li><a class="twitter_icon" href="http://BarrackObamawasourwinnerfortheDuelLegoBoxonthe21stDecember2014"><i class="fa fa-twitter"></i></a></li>
                    <li><a class="google_icon" href="http://BarrackObamawasourwinnerfortheDuelLegoBoxonthe21stDecember2014"><i class="fa fa-google-plus"></i></a></li></ul>
 
 </div>
 
 </div>
<div class="row winnersrow">
 <div class="span3 winnerimg"><img src="image/raffle-img2.png"  alt="Raffle winners"></div>
 <div class="span9 winnerinfo">
 <h4>China Man</h4>
					<p class="member_position">Winner 03/02/2015</p>
					
<p>China Man&nbsp;was our winner for the Duel Lego Box on the 21st December 2014. Then we fill in loads more text about a farm Animal with a machine Gun that shoots out potatoes.&nbsp;Then we fill in loads more text about a farm Animal with a machine Gun that shoots out potatoes.And the we go ahead and enter loads of more text because it looks much better to have a certain amount of text rather than a empty pocket</p>

					<ul class="social_links unstyled"><li><a class="facebook_icon" href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a></li><li><a class="twitter_icon" href="https://www.twitter.com/"><i class="fa fa-twitter"></i></a></li><li><a class="google_icon" href="https://www.google.com/"><i class="fa fa-google-plus"></i></a></li></ul>
 
 
 
 </div>
 
 </div>
 <div class="row winnersrow">
 <div class="span3 winnerimg"><img src="image/raffle-img3.png"  alt="Raffle winners"></div>
 <div class="span9 winnerinfo">
 
 <h4>My No Idea</h4>
					<p class="member_position">Winner 12/12/2014</p>
					
<p>Mr No Body was our winner for the Duel Lego Box on the 21st December 2014. Then we fill in loads more text about a farm Animal with a machine Gun that shoots out potatoes. Then we fill in loads more text about a farm Animal with a machine Gun that shoots out potatoes.And the we go ahead and enter loads of more text because it looks much better to have a certain amount of text rather than a empty pocket</p>

						<ul class="social_links unstyled"><li><a class="facebook_icon" href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a></li><li><a class="twitter_icon" href="https://www.twitter.com/"><i class="fa fa-twitter"></i></a></li><li><a class="google_icon" href="https://www.google.com/"><i class="fa fa-google-plus"></i></a></li></ul>
 
 </div>
 
 </div>
 <div class="row winnersrow">
 <div class="span3 winnerimg"><img src="image/raffle-img4.png"  alt="Raffle winners"></div>
 <div class="span9 winnerinfo">
 
 <h4>Zamar Herz</h4>
					<p class="member_position">Winner</p>
					
<p>Zamar Herz was our winner for the Barbie Doll of the 5th January 2015. Then we fill in loads more text about a farm Animal with a machine Gun that shoots out potatoes.And the we go ahead and enter loads of more text because it looks much better to have a certain amount of text rather than a empty pocket

</p>
	<ul class="social_links unstyled"><li><a class="facebook_icon" href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a></li><li><a class="twitter_icon" href="https://www.twitter.com/"><i class="fa fa-twitter"></i></a></li><li><a class="google_icon" href="https://www.google.com/"><i class="fa fa-google-plus"></i></a></li></ul>
 
 </div>
 
 </div>
 <div class="row winnersrow">
 <div class="span3 winnerimg"><img src="image/raffle-img5.png"  alt="Raffle winners"></div>
 <div class="span9 winnerinfo">
 
 <h4>Bin Ladin</h4>
					<p class="member_position">Winner</p>
					
<p>Bin Ladin was our winner for the Duel Lego Box on the 21st December 2014. Then we fill in loads more text about a farm Animal with a machine Gun that shoots out potatoes.And the we go ahead and enter loads of more text because it looks much better to have a certain amount of text rather than a empty pocket</p>

					<ul class="social_links unstyled"><li><a class="facebook_icon" href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a></li><li><a class="twitter_icon" href="https://www.twitter.com/"><i class="fa fa-twitter"></i></a></li><li><a class="google_icon" href="https://www.google.com/"><i class="fa fa-google-plus"></i></a></li></ul>
 
 </div>
 
 </div>
 
   <div class="row winnersrow">
 <div class="span3 winnerimg"><img src="image/raffle-img6.png"  alt="Raffle winners"></div>
 <div class="span9 winnerinfo">
 
 <h4>Barrack Obama</h4>
					<p class="member_position">Winner</p>
					
<p>Barrack Obama was our winner for the Duel Lego Box on the 21st December 2014. Then we fill in loads more text about a farm Animal with a machine Gun that shoots out potatoes.And the we go ahead and enter loads of more text because it looks much better to have a certain amount of text rather than a empty pocket</p>

					<ul class="social_links unstyled"><li><a class="facebook_icon" href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a></li><li><a class="twitter_icon" href="https://www.twitter.com/"><i class="fa fa-twitter"></i></a></li><li><a class="google_icon" href="https://www.google.com/"><i class="fa fa-google-plus"></i></a></li></ul>
 
 </div>
 
 </div>
    </div>
  </section>
</div>