<section class="banner">
<img src="image/slide1.jpg" alt="Banner">
 </section>
<div id="maincontainer">
  <section id="gopremium">
    <div class="container">
     <h1 class="heading1"><span class="maintext">Go Premium </span></h1>

<div class="go-premium-section">
<a href="index.php" class="">Go Premium</a>

</div>




    </div>
  </section>
</div>