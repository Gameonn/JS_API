<div id="maincontainer">
  <section id="product">
    <div class="container">
     <!--  breadcrumb --> 
            
      <h1 class="heading1"><span class="maintext"> Thanks for Shopping</span></h1>
      <!-- Cart-->
      <p>Curabitur vel viverra nunc, eu auctor odio. Fusce commodo dictum felis, ut tincidunt nisl. Mauris tempus ante vitae placerat auctor. Nullam id justo a orci accumsan lobortis. Phasellus id lobortis nulla. Mauris non suscipit tortor. Vivamus ac justo nunc. Aenean ut purus pretium velit vulputate laoreet non ut nisl. Vivamus erat risus, euismod vel sapien consequat, cursus sodales felis. Morbi pellentesque non justo quis luctus. Duis aliquam, leo ut maximus sollicitudin, sapien felis cursus magna, nec faucibus velit odio sit amet ligula. </p>
            <p>Curabitur vel viverra nunc, eu auctor odio. Fusce commodo dictum felis, ut tincidunt nisl. Mauris tempus ante vitae placerat auctor. Nullam id justo a orci accumsan lobortis. Phasellus id lobortis nulla. Mauris non suscipit tortor. Vivamus ac justo nunc. Aenean ut purus pretium velit vulputate laoreet non ut nisl. Vivamus erat risus, euismod vel sapien consequat, cursus sodales felis. Morbi pellentesque non justo quis luctus. Duis aliquam, leo ut maximus sollicitudin, sapien felis cursus magna, nec faucibus velit odio sit amet ligula. </p>
             <p>
      <input type="submit" onclick="window.location.href='index.php'" value="Continue Shopping" class="btn btn-orange pull-left mr10"></p>
      <p>&nbsp;</p>
       <p>&nbsp;</p>
        <p>&nbsp;</p>
         <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
       <p>&nbsp;</p>
        <p>&nbsp;</p>
         <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
       <p>&nbsp;</p>
        <p>&nbsp;</p>
         <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
       <p>&nbsp;</p>
        <p>&nbsp;</p>
         <p>&nbsp;</p>
          <p>&nbsp;</p>
      
    </div>
  </section>
</div>